function mostrarVista(url){
    document.location.pathname = url;
}