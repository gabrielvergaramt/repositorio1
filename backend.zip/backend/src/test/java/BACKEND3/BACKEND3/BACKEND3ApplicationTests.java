package BACKEND3.BACKEND3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BACKEND3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
