package BACKEND3.BACKEND3.controladores;

import BACKEND3.BACKEND3.modelo.Category;
import BACKEND3.BACKEND3.servicios.CategoryServicio;
import BACKEND3.BACKEND3.servicios.ServicioGenericoAbstracto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/Category")
@CrossOrigin("*")
public class CategoryApiRest extends ControladorGenericoAbstracto<Category, Long> {

    @Autowired
    private CategoryServicio servicio;

    @Override
    public ServicioGenericoAbstracto<Category, Long> getService() {
        return servicio;
    }
}
