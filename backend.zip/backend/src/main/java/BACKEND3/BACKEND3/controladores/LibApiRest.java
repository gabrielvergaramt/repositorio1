package BACKEND3.BACKEND3.controladores;

import BACKEND3.BACKEND3.modelo.Lib;
import BACKEND3.BACKEND3.servicios.LibServicio;
import BACKEND3.BACKEND3.servicios.ServicioGenericoAbstracto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/Lib")
@CrossOrigin("*")
public class LibApiRest extends ControladorGenericoAbstracto<Lib, Long> {

    @Autowired
    private LibServicio servicio;

    @Override
    public ServicioGenericoAbstracto<Lib, Long> getService() {
        return servicio;
    }
}
