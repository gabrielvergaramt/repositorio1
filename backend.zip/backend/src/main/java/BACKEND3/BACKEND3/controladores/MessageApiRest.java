package BACKEND3.BACKEND3.controladores;

import BACKEND3.BACKEND3.modelo.Message;
import BACKEND3.BACKEND3.servicios.MessageServicio;
import BACKEND3.BACKEND3.servicios.ServicioGenericoAbstracto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/Message")
@CrossOrigin("*")
public class MessageApiRest extends ControladorGenericoAbstracto<Message, Long> {

    @Autowired
    private MessageServicio servicio;

    @Override
    public ServicioGenericoAbstracto<Message, Long> getService() {
        return servicio;
    }
}

