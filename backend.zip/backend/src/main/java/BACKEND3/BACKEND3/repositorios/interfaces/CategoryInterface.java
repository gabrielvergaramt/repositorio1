package BACKEND3.BACKEND3.repositorios.interfaces;

import BACKEND3.BACKEND3.modelo.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryInterface extends CrudRepository<Category,Long> {
}
