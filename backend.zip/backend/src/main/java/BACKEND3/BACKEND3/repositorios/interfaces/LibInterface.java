package BACKEND3.BACKEND3.repositorios.interfaces;

import BACKEND3.BACKEND3.modelo.Lib;
import org.springframework.data.repository.CrudRepository;

public interface LibInterface extends CrudRepository<Lib,Long> {
}
