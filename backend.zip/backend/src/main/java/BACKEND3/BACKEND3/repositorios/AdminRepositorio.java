package BACKEND3.BACKEND3.repositorios;

import BACKEND3.BACKEND3.modelo.Admin;
import BACKEND3.BACKEND3.repositorios.interfaces.AdminInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public class AdminRepositorio extends RepositorioGenericoAbstracto<Admin,Long>{

    @Autowired
    private AdminInterface anInterface;

    @Override
    public CrudRepository<Admin, Long> getDao() {
        return anInterface;
    }

}
