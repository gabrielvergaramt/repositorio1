package BACKEND3.BACKEND3.repositorios.interfaces;

import BACKEND3.BACKEND3.modelo.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminInterface extends CrudRepository<Admin,Long> {
}
