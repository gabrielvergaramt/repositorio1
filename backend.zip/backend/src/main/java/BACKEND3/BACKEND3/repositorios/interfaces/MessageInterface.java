package BACKEND3.BACKEND3.repositorios.interfaces;

import BACKEND3.BACKEND3.modelo.Message;
import org.springframework.data.repository.CrudRepository;

public interface MessageInterface extends CrudRepository<Message,Long> {
}

