package BACKEND3.BACKEND3.repositorios.interfaces;

import BACKEND3.BACKEND3.modelo.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientInterface extends CrudRepository<Client,Long> {
}
