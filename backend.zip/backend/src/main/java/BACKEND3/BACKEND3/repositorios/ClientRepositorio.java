package BACKEND3.BACKEND3.repositorios;

import BACKEND3.BACKEND3.modelo.Client;
import BACKEND3.BACKEND3.repositorios.interfaces.ClientInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public class ClientRepositorio extends RepositorioGenericoAbstracto<Client,Long>{

    @Autowired
    private ClientInterface anInterface;

    @Override
    public CrudRepository<Client, Long> getDao() {
        return anInterface;
    }
}