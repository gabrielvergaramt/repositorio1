package BACKEND3.BACKEND3.repositorios;

import BACKEND3.BACKEND3.modelo.Reservation;
import BACKEND3.BACKEND3.repositorios.interfaces.ReservationInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public class ReservationRepositorio extends RepositorioGenericoAbstracto<Reservation,Long>{

    @Autowired
    private ReservationInterface anInterface;

    @Override
    public CrudRepository<Reservation, Long> getDao() {
        return anInterface;
    }
}
