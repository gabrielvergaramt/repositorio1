package BACKEND3.BACKEND3.repositorios.interfaces;

import BACKEND3.BACKEND3.modelo.Score;
import org.springframework.data.repository.CrudRepository;

public interface ScoreInterface extends CrudRepository<Score,Long> {
}